Blatt 4

Aufgabe 1a.) 	bearbeitet und funktionsfähig
Aufgabe 1b.)	bearbeitet und funktionsfähig
Aufgabe 1c.)	bearbeitet und funktionsfähig
Aufgabe 1d.)	bearbeitet und funktionsfähig

Gesamte Aufgabe 1 funktioniert in der Ausführeung fehlerfrei
Abgabe Blatt 6 Gruppe N

Aufgabe: 1
a.) und b.)	bearbeitet
c.)		bearbeitet; Abgabe-Kommentar: die Antwort auf die Aufgabe befindet sich im Dokument als Kommentar

Aufgabe: 2	bearbeitet